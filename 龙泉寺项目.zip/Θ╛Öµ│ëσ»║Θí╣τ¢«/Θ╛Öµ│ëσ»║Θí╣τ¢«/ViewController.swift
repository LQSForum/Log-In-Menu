import UIKit
class ViewController: UIViewController {
    override func viewDidLoad() {
        self.view.backgroundColor=UIColor.blackColor()
        super.viewDidLoad()
    }
    override func viewDidAppear(animated:Bool){
        presentLogIn(self)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}

