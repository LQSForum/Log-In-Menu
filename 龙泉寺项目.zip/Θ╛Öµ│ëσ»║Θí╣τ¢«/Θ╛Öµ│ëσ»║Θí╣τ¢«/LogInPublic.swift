import UIKit
import Foundation
func presentLogIn(i:UIViewController){ // 弹出登陆窗口
    let livc=LogInViewController()
    let modalStyle:UIModalTransitionStyle=UIModalTransitionStyle.CoverVertical
    i.modalTransitionStyle=modalStyle
    i.presentViewController(livc,animated:true,completion:nil)
}
func sendLogInRequest(name:String,code:String){ // 发送登陆请求至服务器
    // 请负责网络部分的同志完善
    // 此函数在LogInViewController文件中调用了
}
func returnLogInResult(successful:Bool){ // 返回数据, 需要负责网络的朋友调用它
    if(successful==true){
        logInState="successful"
    }else{
        logInState="tryAgain"
    }
}