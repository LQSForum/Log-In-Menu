import UIKit
import Foundation
var logInState:String="normal"
class LogInViewController:UIViewController,UITextFieldDelegate{
    //输入框
    var txtUser:UITextField!
    var txtPwd:UITextField!
    //外框
    var vLogin:UIView!
    var raised:Bool=false
    //按钮
    var loginButton=UIButton()
    var signButton=UIButton()
    var loginAvailable:Bool=false
    var signAvailable:Bool=true
    var loading:Bool=false
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor=UIColor.whiteColor()
        logInState="normal"
        //登录框背景
        vLogin=UIView(frame:CGRectMake(20,130,
            UIScreen.mainScreen().bounds.size.width - 40,220))
        vLogin.layer.borderWidth = 0.5
        vLogin.layer.cornerRadius = 8
        vLogin.layer.borderColor = UIColor.lightGrayColor().CGColor
        vLogin.backgroundColor = UIColor.whiteColor()
        self.view.addSubview(vLogin)
        //按钮
        loginButton=UIButton(frame:CGRectMake(30,154,vLogin.frame.size.width/2 - 40, 44))
        loginButton.layer.cornerRadius = 8
        self.loginButton.layer.backgroundColor=UIColor.grayColor().CGColor
        loginButton.setTitle("返回", forState: UIControlState.Normal)
        loginButton.setTitleColor(UIColor.whiteColor(), forState: UIControlState.Normal)
        self.vLogin.addSubview(loginButton)
        signButton=UIButton(frame:CGRectMake(loginButton.frame.size.width+50,154,
            vLogin.frame.size.width/2 - 40, 44))
        signButton.layer.cornerRadius = 8
        signButton.layer.backgroundColor=UIColor(red:256.0/256.0,green:150.0/256.0,blue:0,alpha:1).CGColor
        signButton.setTitle("注册", forState: UIControlState.Normal)
        signButton.setTitleColor(UIColor.whiteColor(), forState: UIControlState.Normal)
        self.vLogin.addSubview(signButton)
        loginButton.addTarget(self, action: #selector(LogInViewController.loginAction), forControlEvents: UIControlEvents.TouchUpInside)
        signButton.addTarget(self, action: #selector(LogInViewController.signAction), forControlEvents: UIControlEvents.TouchUpInside)
        //用户名输入框
        txtUser = UITextField(frame:CGRectMake(30, 30, vLogin.frame.size.width - 60, 44))
        txtUser.placeholder="用户名"
        txtUser.delegate = self
        txtUser.layer.cornerRadius = 5
        txtUser.layer.borderColor = UIColor.lightGrayColor().CGColor
        txtUser.layer.borderWidth = 0.5
        txtUser.leftView = UIView(frame:CGRectMake(0, 0, 44, 44))
        txtUser.leftViewMode = UITextFieldViewMode.Always
        txtUser.autocorrectionType=UITextAutocorrectionType.No
        txtUser.autocapitalizationType=UITextAutocapitalizationType.None
        let imgUser =  UIImageView(frame:CGRectMake(12, 12, 20, 20))
        imgUser.image = UIImage(named:"iconfont-user")
        txtUser.leftView!.addSubview(imgUser)
        vLogin.addSubview(txtUser)
        let centerDefault=NSNotificationCenter.defaultCenter()
        //密码输入框
        txtPwd = UITextField(frame:CGRectMake(30, 90, vLogin.frame.size.width - 60, 44))
        txtPwd.placeholder="密码"
        txtPwd.delegate = self
        txtPwd.layer.cornerRadius = 5
        txtPwd.layer.borderColor = UIColor.lightGrayColor().CGColor
        txtPwd.layer.borderWidth = 0.5
        txtPwd.secureTextEntry = true
        txtPwd.leftView = UIView(frame:CGRectMake(0, 0, 44, 44))
        txtPwd.leftViewMode = UITextFieldViewMode.Always
        let imgPwd =  UIImageView(frame:CGRectMake(11, 11, 22, 22))
        imgPwd.image = UIImage(named:"iconfont-password")
        txtPwd.leftView!.addSubview(imgPwd)
        vLogin.addSubview(txtPwd)
        centerDefault.addObserver(self, selector: #selector(LogInViewController.textChanged), name: UITextFieldTextDidChangeNotification, object: nil)
        //触摸检测
        let pressGesture=UITapGestureRecognizer(target:self,action:#selector(LogInViewController.press(_:)))
        self.view.addGestureRecognizer(pressGesture)
        _=NSTimer.scheduledTimerWithTimeInterval(0.5, target: self, selector: #selector(self.update), userInfo: nil, repeats: true)
    }
    //更新
    func textChanged(){
        if(txtUser.text != "")&&(txtPwd.text != ""){
            if(loginAvailable==false){
                UIView.animateWithDuration(0.3, animations: { () -> Void in
                    self.loginButton.layer.backgroundColor=UIColor(red:90.0/256.0,green:180.0/256.0,blue:0,alpha:1).CGColor
                })
            }
            loginAvailable=true
        }else{
            if(loginAvailable==true){
                UIView.animateWithDuration(0.3, animations: { () -> Void in
                    self.loginButton.layer.backgroundColor=UIColor.grayColor().CGColor
                })
            }
            loginAvailable=false
        }
    }
    //触摸检测
    func press(gestureRecognize:UIGestureRecognizer){
        txtUser.resignFirstResponder()
        txtPwd.resignFirstResponder()
        if(raised==true){
            UIView.animateWithDuration(0.5, animations: { () -> Void in
                self.vLogin.frame = CGRectMake(20,130,
                    UIScreen.mainScreen().bounds.size.width - 40,220)
            })
            raised=false
        }
        if(txtUser.text=="")&&(txtPwd.text=="")&&(signAvailable==false){
            signAvailable=true
            UIView.animateWithDuration(0.5, animations: { () -> Void in
                self.loginButton.frame = CGRectMake(30,154,self.vLogin.frame.size.width/2 - 40, 44)
                self.signButton.frame=CGRectMake(self.vLogin.frame.size.width/2+10,154,
                    self.vLogin.frame.size.width/2 - 40, 44)
                self.loginButton.setTitle("返回", forState: UIControlState.Normal)
            })
        }
    }
    //开始编辑
    func textFieldDidBeginEditing(textField:UITextField) {
        if(raised==false){
            UIView.animateWithDuration(0.5, animations: { () -> Void in
                self.vLogin.frame = CGRectMake(20,70,
                    UIScreen.mainScreen().bounds.size.width - 40,220)
            })
            raised=true
        }
        if(signAvailable==true){
            signAvailable=false
            UIView.animateWithDuration(0.5, animations: { () -> Void in
                self.loginButton.frame = CGRectMake(30,154,self.vLogin.frame.size.width-60,44)
                self.signButton.frame=CGRectMake(self.txtUser.frame.size.width+30,154,0, 44)
                self.loginButton.setTitle("登陆", forState: UIControlState.Normal)
            })
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    func loginAction(){
        if(loginAvailable==true){
            sendLogInRequest(txtUser.text!,code: txtPwd.text!)
            if(logInState != "waiting"){
                txtUser.resignFirstResponder()
                txtPwd.resignFirstResponder()
                if(raised==true){
                    UIView.animateWithDuration(0.5, animations: { () -> Void in
                        self.vLogin.frame = CGRectMake(20,130,
                            UIScreen.mainScreen().bounds.size.width - 40,220)
                    })
                    raised=false
                }
                UIView.animateWithDuration(0.3, animations: { () -> Void in
                    self.loginButton.layer.backgroundColor=UIColor.grayColor().CGColor
                    self.loginButton.setTitle("登陆确认中", forState: UIControlState.Normal)
                    self.txtUser.enabled=false
                    self.txtPwd.enabled=false
                })
            }
            logInState="waiting"
        }else if(signAvailable==true){
            dismiss()
        }
    }
    func signAction(){
        self.dismissViewControllerAnimated(true, completion: {})
    }
    @objc func update(){
        if(logInState=="tryAgain"){
            UIView.animateWithDuration(0.3, animations: { () -> Void in
                self.loginButton.setTitle("登陆失败", forState: UIControlState.Normal)
                self.loginButton.layer.backgroundColor=UIColor(red:200.0/256.0,green:0,blue:0,alpha:1).CGColor
            })
            _=NSTimer.scheduledTimerWithTimeInterval(1, target: self, selector: #selector(self.restart), userInfo: nil, repeats: false)
            logInState="tryAgained"
        }
        if(logInState=="successful"){
            UIView.animateWithDuration(0.3, animations: { () -> Void in
                self.loginButton.setTitle("登陆成功", forState: UIControlState.Normal)
                self.loginButton.layer.backgroundColor=UIColor(red:200.0/256.0,green:200.0/256.0,blue:200.0/256.0,alpha:1).CGColor
            })
            _=NSTimer.scheduledTimerWithTimeInterval(1, target: self, selector: #selector(self.dismiss), userInfo: nil, repeats: false)
            logInState="successfuled"
        }
    }
    @objc func restart(){
        self.txtUser.enabled=true
        self.txtPwd.enabled=true
        self.txtUser.text=""
        self.txtPwd.text=""
        signAvailable=true
        loginAvailable=false
        UIView.animateWithDuration(0.5, animations: { () -> Void in
            self.loginButton.frame = CGRectMake(30,154,self.vLogin.frame.size.width/2 - 40, 44)
            self.signButton.frame=CGRectMake(self.vLogin.frame.size.width/2+10,154,
                self.vLogin.frame.size.width/2 - 40, 44)
            self.loginButton.setTitle("返回", forState: UIControlState.Normal)
            self.loginButton.layer.backgroundColor=UIColor.grayColor().CGColor
        })
        logInState="normal"
    }
    @objc func dismiss(){
        self.dismissViewControllerAnimated(true, completion: {})
    }
}